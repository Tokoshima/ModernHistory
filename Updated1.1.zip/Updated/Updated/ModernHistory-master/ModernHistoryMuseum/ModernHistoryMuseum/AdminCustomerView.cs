﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ModernHistoryMuseum
{
    public partial class AdminCustomerView : Form
    {
        public AdminCustomerView()
        {
            InitializeComponent();
        }
        public string conString = @"Data Source=DESKTOP-NQ2GKGC\SQLEXPRESS;Initial Catalog=ModernHistoryMuseum;Integrated Security=True";

        SqlConnection con;
        DataSet ds;
        SqlDataAdapter adap;

        private void AdminCustomerView_Load(object sender, EventArgs e)
        {
             con = new SqlConnection(conString);
            con.Open();

            string select = "SELECT * FROM CUSTOMER";

            SqlCommand cmd = new SqlCommand(select, con);
            ds = new DataSet();
            adap = new SqlDataAdapter();
            adap.SelectCommand = cmd;
            adap.Fill(ds, "table");
            dgvAdminCustomer.DataSource = ds;
            dgvAdminCustomer.DataMember = "table";
            con.Close();
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string sSearch = txtSearch.Text;
            try
            {
                con.Open();
                adap = new SqlDataAdapter();
                ds = new DataSet();
                string sqlSelect = "SELECT * FROM CUSTOMER WHERE Customer_FName LIKE '%" + sSearch + "%'";
                SqlCommand cmd = new SqlCommand(sqlSelect, con);

                adap.SelectCommand = cmd;
                adap.Fill(ds, "Customer");

                dgvAdminCustomer.DataSource = ds;
                dgvAdminCustomer.DataMember = "Customer";
                con.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            if(this.dgvAdminCustomer.SelectedRows.Count > 0)
            {
                dgvAdminCustomer.Rows.RemoveAt(this.dgvAdminCustomer.SelectedRows[0].Index);
                MessageBox.Show("Record deleted");
           
            }

            
           
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {

        }
    }
}
