﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace ModernHistoryMuseum
{
    public partial class AdminEventView : Form
    {
        public string constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\25046659\Desktop\prakt4\prakt4\Majors.mdf;Integrated Security=True";
        public SqlConnection conn;
        public SqlCommand comm;
        public SqlDataAdapter adap;
        public DataSet ds;
        public SqlDataReader dr;
        public AdminEventView()
        {
            InitializeComponent();
        }

        private void AdminEventView_Load(object sender, EventArgs e)
        {
            string select_All = "SELECT * FROM tbl";

            try
            {
                conn.Open();
                comm = new SqlCommand(select_All, conn);
                ds = new DataSet();
                adap = new SqlDataAdapter();

                adap.SelectCommand = comm;
                adap.Fill(ds, "Show");
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Show";

                conn.Close();
                comm.Dispose();
            }
            catch (SqlException err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        { 
            String AddTable = "INSERT INTO InfoTable VALUES(@StudentID, @Student_FirstName, @Student_LastName, @Major_ID, @Student_Phone)";



            try
            {
                conn.Open();
                comm = new SqlCommand(AddTable, conn);
                comm.Parameters.AddWithValue("@StudentID", insert.studentid);
                comm.Parameters.AddWithValue("@Student_FirstName", insert.firstName);
                comm.Parameters.AddWithValue("@Student_LastName", insert.lastName);
                comm.Parameters.AddWithValue("@Major_ID", insert.majorid);
                comm.Parameters.AddWithValue("@Student_Phone", insert.studentphone);
                comm.ExecuteNonQuery();
            }
            catch (SqlException err)
            {
                MessageBox.Show(err.Message);
            }

            string select_All = "SELECT * FROM InfoTable";

            try
            {
                comm = new SqlCommand(select_All, conn);
                ds = new DataSet();
                adap = new SqlDataAdapter();

                adap.SelectCommand = comm;
                adap.Fill(ds, "Show");
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Show";
            }
            catch (SqlException err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
            Remove Removal = new Remove();
            Removal.ShowDialog();


            string delete = "DELETE FROM  ";

            try
            {
                conn.Open();
                comm = new SqlCommand(delete, conn);
                comm.ExecuteNonQuery();
                conn.Close();
            }
            catch (SqlException err)
            {
                MessageBox.Show(err.Message);
            }

            string select_All = "SELECT * FROM InfoTable";

            try
            {
                comm = new SqlCommand(select_All, conn);
                ds = new DataSet();
                adap = new SqlDataAdapter();

                adap.SelectCommand = comm;
                adap.Fill(ds, "Show");
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Show";
            }
            catch (SqlException err)
            {
                MessageBox.Show(err.Message);
            }

            conn.Close();
            comm.Dispose();
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            string sql_Update = "UPDATE Menu SET Price = '" + pug + "' WHERE Name = '" + ddlstChangePrice.Text + "'";

            try
            {
                conn = new SqlConnection(connstr);
                conn.Open();

                comm = new SqlCommand(sql_Update, conn);
                comm.ExecuteNonQuery();

                conn.Close();
                comm.Dispose();
            }
            catch (SqlException err)
            {
                lblErr.Text = err.Message;
                lblErr.Visible = true;
            }

            try
            {
                conn = new SqlConnection(connstr);
                comm = new SqlCommand(sql_All, conn);
                adap = new SqlDataAdapter();
                ds = new DataSet();

                adap.SelectCommand = comm;
                adap.Fill(ds);

                GridView1.DataSource = ds;
                GridView1.DataBind();

                conn.Close();
                comm.Dispose();
                adap.Dispose();
            }
            catch (SqlException err)
            {
                lblErr.Text = err.Message;
                lblErr.Visible = true;
            }
        }

        private void TxtUpdate_TextChanged(object sender, EventArgs e)
        {
            String AddTable = "INSERT INTO InfoTable VALUES(@StudentID, @Student_FirstName, @Student_LastName, @Major_ID, @Student_Phone)";



            try
            {
                conn.Open();
                comm = new SqlCommand(AddTable, conn);
                comm.Parameters.AddWithValue("@StudentID", insert.studentid);
                comm.Parameters.AddWithValue("@Student_FirstName", insert.firstName);
                comm.Parameters.AddWithValue("@Student_LastName", insert.lastName);
                comm.Parameters.AddWithValue("@Major_ID", insert.majorid);
                comm.Parameters.AddWithValue("@Student_Phone", insert.studentphone);
                comm.ExecuteNonQuery();
            }
            catch (SqlException err)
            {
                MessageBox.Show(err.Message);
            }

            string select_All = "SELECT * FROM InfoTable";

            try
            {
                comm = new SqlCommand(select_All, conn);
                ds = new DataSet();
                adap = new SqlDataAdapter();

                adap.SelectCommand = comm;
                adap.Fill(ds, "Show");
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Show";
            }
            catch (SqlException err)
            {
                MessageBox.Show(err.Message);
            }
        }
    }
}
