﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ModernHistoryMuseum
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }
        public string conString = @"Data Source=DESKTOP-NQ2GKGC\SQLEXPRESS;Initial Catalog=ModernHistoryMuseum;Integrated Security=True";

        private void Button1_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Robbie is big gay");
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("dis nie baie nice nie Louw");
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            string sUser = txtUser.Text;
            string sPass = txtPass.Text;

            if ((sUser == "") || (sPass == ""))
            {
                MessageBox.Show("Please enter your information");
            }

            SqlConnection con = new SqlConnection(conString);
            con.Open();

            SqlCommand sqlCheck = new SqlCommand("SELECT COUNT(*) FROM CUSTOMER WHERE Customer_UserName = @User", con);
            sqlCheck.Parameters.AddWithValue("@User", sUser);
            int UserExists = Convert.ToInt32(sqlCheck.ExecuteScalar());

            if (UserExists > 0)
            {
                MessageBox.Show("Welcome " + sUser);
                CustomerExhibitView frmCEV = new CustomerExhibitView();
                frmCEV.Show();
                this.Hide();

            }
            else
            {
                MessageBox.Show("Please register!");
                Register frmReg = new Register();
                frmReg.Show();
                this.Hide();
            }
            con.Close();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            Register frmReg = new Register();
            frmReg.Show();
            this.Hide();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            AdminView frmAdmin = new AdminView();
            frmAdmin.Show();
            this.Hide();
        }

        private void BtnExit_Click(object sender, EventArgs e)
        {

        }
    }
}
