﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace ModernHistoryMuseum
{
    public partial class CustomerExhibitView : Form
    {
        public string constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\25046659\Desktop\prakt4\prakt4\Majors.mdf;Integrated Security=True";
        public SqlConnection conn;
        public SqlCommand comm;
        public SqlDataAdapter adap;
        public DataSet ds;
        public SqlDataReader dr;
        public CustomerExhibitView()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void cmbSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            conn.open();
            SqlCommand command;
            string sql;
            SqlDataAdapter adapter = new SqlDataAdapter();
            sql = @"Select * FROM TableInformation Where Surnames ='" + cmbSelect.SelectedValue + "'";
            command = new SqlCommand(sql, conn);
            DataSet ds = new DataSet();
            adapter.SelectCommand = command;
            adapter.Fill(ds, "TableInformation");
            dataGridView1.DataSource = ds;
            dataGridView1.DataMember = "TableInformation";
            conn.Close();
        }

        private void CustomerExhibitView_Load(object sender, EventArgs e)
        {
            conn.Open();
            SqlCommand command;
            string sql;
            SqlDataAdapter adapter = new SqlDataAdapter();
            sql = @"Select Surnames FROM TableInformation";
            command = new SqlCommand(sql, conn);
            DataSet ds = new DataSet();
            adapter.SelectCommand = command;
            adapter.Fill(ds, "TableInformation");
            cmbSelect.DisplayMember = "Surnames";
            cmbSelect.ValueMember = "Surnames";
            cmbSelect.DataSource = ds.Tables["TableInformation"];
            //conn.close()
        }
    }
}
