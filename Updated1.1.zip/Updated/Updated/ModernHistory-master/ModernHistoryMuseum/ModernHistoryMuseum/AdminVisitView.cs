﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ModernHistoryMuseum
{
    public partial class AdminVisitView : Form
    {
        public string constr = @"Data Source=(LocalDB)\MSSQLLocalDB;AttachDbFilename=C:\Users\25046659\Desktop\prakt4\prakt4\Majors.mdf;Integrated Security=True";
        public SqlConnection conn;
        public SqlCommand comm;
        public SqlDataAdapter adap;
        public DataSet ds;
        public SqlDataReader dr;
        public AdminVisitView()
        {
            InitializeComponent();
        }

        private void AdminVisitView_Load(object sender, EventArgs e)
        {
            string select_All = "SELECT * FROM tbl";

            try
            {
                conn.Open();
                comm = new SqlCommand(select_All, conn);
                ds = new DataSet();
                adap = new SqlDataAdapter();

                adap.SelectCommand = comm;
                adap.Fill(ds, "Show");
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Show";

                conn.Close();
                comm.Dispose();
            }
            catch (SqlException err)
            {
                MessageBox.Show(err.Message);
            }
        }
    }
}
