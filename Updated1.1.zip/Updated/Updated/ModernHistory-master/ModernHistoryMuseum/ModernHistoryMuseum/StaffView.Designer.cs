﻿namespace ModernHistoryMuseum
{
    partial class StaffView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnEvent = new System.Windows.Forms.Button();
            this.btnExhibit = new System.Windows.Forms.Button();
            this.btnProp = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.btnHelp = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnEvent
            // 
            this.btnEvent.Location = new System.Drawing.Point(41, 134);
            this.btnEvent.Name = "btnEvent";
            this.btnEvent.Size = new System.Drawing.Size(123, 76);
            this.btnEvent.TabIndex = 2;
            this.btnEvent.Text = "View Events";
            this.btnEvent.UseVisualStyleBackColor = true;
            // 
            // btnExhibit
            // 
            this.btnExhibit.Location = new System.Drawing.Point(170, 52);
            this.btnExhibit.Name = "btnExhibit";
            this.btnExhibit.Size = new System.Drawing.Size(123, 76);
            this.btnExhibit.TabIndex = 3;
            this.btnExhibit.Text = "StaffStaffView";
            this.btnExhibit.UseVisualStyleBackColor = true;
            // 
            // btnProp
            // 
            this.btnProp.Location = new System.Drawing.Point(103, 216);
            this.btnProp.Name = "btnProp";
            this.btnProp.Size = new System.Drawing.Size(123, 76);
            this.btnProp.TabIndex = 5;
            this.btnProp.Text = "View Props";
            this.btnProp.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(41, 52);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(123, 76);
            this.button7.TabIndex = 6;
            this.button7.Text = "View Staff";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(170, 134);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(123, 76);
            this.button8.TabIndex = 7;
            this.button8.Text = "View Customer";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // btnHelp
            // 
            this.btnHelp.Location = new System.Drawing.Point(218, 12);
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Size = new System.Drawing.Size(75, 33);
            this.btnHelp.TabIndex = 16;
            this.btnHelp.Text = "Help";
            this.btnHelp.UseVisualStyleBackColor = true;
            // 
            // StaffView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(329, 341);
            this.Controls.Add(this.btnHelp);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.btnProp);
            this.Controls.Add(this.btnExhibit);
            this.Controls.Add(this.btnEvent);
            this.Name = "StaffView";
            this.Text = "StaffStaffView";
            this.Load += new System.EventHandler(this.StaffView_Load);
            this.ResumeLayout(false);

        }

        #endregion
        private System.Windows.Forms.Button btnEvent;
        private System.Windows.Forms.Button btnExhibit;
        private System.Windows.Forms.Button btnProp;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button btnHelp;
    }
}