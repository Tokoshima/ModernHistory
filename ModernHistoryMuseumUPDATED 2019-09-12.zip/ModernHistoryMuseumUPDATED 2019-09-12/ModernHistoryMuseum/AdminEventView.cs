﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace ModernHistoryMuseum
{
    public partial class AdminEventView : Form
    {
        public string constr = @"Data Source=DESKTOP-NQ2GKGC\SQLEXPRESS;Initial Catalog=ModernHistoryMuseum_Fixed;Integrated Security=True";
        public SqlConnection conn;
        public SqlCommand comm;
        public SqlDataAdapter adap;
        public DataSet ds;
        public SqlDataReader dr;
        public AdminEventView()
        {
            InitializeComponent();
        }

        private void AdminEventView_Load(object sender, EventArgs e)
        {
            string select_All = "SELECT * FROM EVENT";

            conn = new SqlConnection(constr);

            try
            {
                conn.Open();
                comm = new SqlCommand(select_All, conn);
                ds = new DataSet();
                adap = new SqlDataAdapter();

                adap.SelectCommand = comm;
                adap.Fill(ds, "Show");
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Show";

                conn.Close();
                comm.Dispose();
            }
            catch (SqlException err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            AE_INSERT frmAdd = new AE_INSERT();
            frmAdd.Show();
          
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
           
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            AE_UPDATE frmUp = new AE_UPDATE();
            frmUp.Show();
        }

        private void TxtUpdate_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string sSearch = txtSearch.Text;
            conn = new SqlConnection(constr);
            try
            {
                conn.Open();
                adap = new SqlDataAdapter();
                ds = new DataSet();
                string sqlSelect = "SELECT * FROM EVENT WHERE Event_Description LIKE '%" + sSearch + "%'";
                SqlCommand cmd = new SqlCommand(sqlSelect, conn);

                adap.SelectCommand = cmd;
                adap.Fill(ds, "Customer");

                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Customer";
                conn.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }
    }
}
