﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ModernHistoryMuseum
{
    public partial class AdminExhibitView : Form
    {
        public string constr = @"Data Source=DESKTOP-NQ2GKGC\SQLEXPRESS;Initial Catalog=ModernHistoryMuseum_Fixed;Integrated Security=True";
        public SqlConnection conn;
        public SqlCommand comm;
        public SqlDataAdapter adap;
        public DataSet ds;
        public SqlDataReader dr;
        public AdminExhibitView()
        {
            InitializeComponent();
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            AEx_INSERT frmAdd = new AEx_INSERT();
            frmAdd.Show();
        }

        private void BtnDelete_Click(object sender, EventArgs e)
        {
           
        }

        private void AdminExhibitView_Load(object sender, EventArgs e)
        {
            string select_All = "SELECT * FROM EXHIBIT";
            conn = new SqlConnection(constr);

            try
            {
                conn.Open();
                comm = new SqlCommand(select_All, conn);
                ds = new DataSet();
                adap = new SqlDataAdapter();

                adap.SelectCommand = comm;
                adap.Fill(ds, "Show");
                dgvAdminExhibit.DataSource = ds;
                dgvAdminExhibit.DataMember = "Show";

                conn.Close();
                comm.Dispose();
            }
            catch (SqlException err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            AEx_UPDATE frmUp = new AEx_UPDATE();
            frmUp.Show();
        }

        private void TxbSearch_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string sSearch = txtSearch.Text;
            conn = new SqlConnection(constr);
            try
            {
                conn.Open();
                adap = new SqlDataAdapter();
                ds = new DataSet();
                string sqlSelect = "SELECT * FROM Exhibit WHERE Event_Description LIKE '%" + sSearch + "%'";
                SqlCommand cmd = new SqlCommand(sqlSelect, conn);

                adap.SelectCommand = cmd;
                adap.Fill(ds, "Customer");

                dgvAdminExhibit.DataSource = ds;
                dgvAdminExhibit.DataMember = "Customer";
                conn.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }
    }
}
