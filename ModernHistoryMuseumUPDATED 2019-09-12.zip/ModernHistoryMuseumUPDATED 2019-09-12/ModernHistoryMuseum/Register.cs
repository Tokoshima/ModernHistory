﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ModernHistoryMuseum
{
    public partial class Register : Form
    {
        public Register()
        {
            InitializeComponent();
        }
        bool isValidEmail(string sEmail)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(sEmail);
                return addr.Address == sEmail;
            }
            catch
            {
                return false;
            }
        }
        public string conString = @"Data Source=DESKTOP-NQ2GKGC\SQLEXPRESS;Initial Catalog=ModernHistoryMuseum_Fixed;Integrated Security=True";

        private void button1_Click(object sender, EventArgs e)
        {
            string sFName = txtFName.Text;
            string sLName = txtLName.Text;
            string sEmail = txtEmail.Text;
            string sCell = txtCell.Text;
            string sUser = txtUser.Text;
            string sPass = txtPass.Text;
            int i = 0;
            i++;

            SqlConnection con = new SqlConnection(conString);

            if (sCell.Length != 10)
            {
                MessageBox.Show("Please enter a valid number");
            }
            if (isValidEmail(sEmail) == false)
            {
                MessageBox.Show("Please enter a valid e-mail address.");
            }


            if ((sFName == "") || (sLName == "") || (sEmail == "") || (sCell == "") || (sUser == "") || (sCell == ""))
            {
                MessageBox.Show("Please fill in the required fields");
            }



            string INSERT = "INSERT INTO CUSTOMER(Customer_LName,Customer_FName,Customer_Email,Customer_Cell,Customer_UserName,Customer_Password) VALUES (@Customer_LName,@Customer_FName,@Customer_Email,@Customer_Cell,@Customer_UserName,@Customer_Password)";
            using (SqlCommand cmd = new SqlCommand(INSERT, con))
            {
                // cmd.Parameters.AddWithValue("@Customer_ID", i);
                cmd.Parameters.AddWithValue("@Customer_LName", sLName);
                cmd.Parameters.AddWithValue("@Customer_FName", sFName);
                cmd.Parameters.AddWithValue("@Customer_Email", sEmail);
                cmd.Parameters.AddWithValue("@Customer_Cell", sCell);
                cmd.Parameters.AddWithValue("@Customer_UserName", sUser);
                cmd.Parameters.AddWithValue("@Customer_Password", sPass);
                i++;

                con.Open();
                int result = cmd.ExecuteNonQuery();

               /* string sCheckUser = "SELECT * FROM CUSTOMER WHERE Customer_UserName = @User";
                SqlCommand checkUser = new SqlCommand(sCheckUser, con);
                checkUser.Parameters.AddWithValue("@User", txtUser.Text);
                SqlDataReader dr = checkUser.ExecuteReader();

                if (dr.HasRows)
                {
                    MessageBox.Show("Username unavailable, please choose another name.");
                    con.Close();
                }*/
                

                if (result < 0)
                {
                    MessageBox.Show("Error inserting into DB");
                }
                else
                {
                    MessageBox.Show("You have registered successfully!");
                }

            }
            //NOTE Event_ID NULL atm*/
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            Login frmLog = new Login();
            frmLog.Show();
            this.Hide();
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void Register_Load(object sender, EventArgs e)
        {

        }
    }
}
