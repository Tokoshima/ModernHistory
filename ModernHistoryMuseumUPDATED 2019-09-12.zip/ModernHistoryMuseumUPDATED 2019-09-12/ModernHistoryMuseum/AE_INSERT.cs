﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ModernHistoryMuseum
{
    public partial class AE_INSERT : Form
    {
        public AE_INSERT()
        {
            InitializeComponent();
        }

        public string conString = @"Data Source=DESKTOP-NQ2GKGC\SQLEXPRESS;Initial Catalog=ModernHistoryMuseum_Fixed;Integrated Security=True";

        private void btnInsert_Click(object sender, EventArgs e)
        {
            SqlConnection con = new SqlConnection(conString);

            string sEvent = txtEventID.Text;
            string sDescription = txtDescription.Text;
            string sDate = txtDate.Text;
            string sEmployee = txtEmployeeID.Text;

            if ((sEmployee == "") || (sDescription == "") || (sEvent == "") || (sDate == ""))
            {
                MessageBox.Show("Please fill in the required fields");
            }

            string INSERT = "INSERT INTO EVENT(Event_ID,Event_Description,Event_Date,Employee_ID) VALUES (@EventID,@Description,@Date,@EmployeeID)";
            using (SqlCommand cmd = new SqlCommand(INSERT, con))
            {

                cmd.Parameters.AddWithValue("@EventID", sEvent);
                cmd.Parameters.AddWithValue("@Description", sDescription);
                cmd.Parameters.AddWithValue("@Date", sDate);
                cmd.Parameters.AddWithValue("@EmployeeID", sEmployee);



                con.Open();
                int result = cmd.ExecuteNonQuery();

                if (result < 0)
                {
                    MessageBox.Show("Error inserting into DB");
                }
                else
                {
                    MessageBox.Show("You have registered successfully!");
                }
            }
        }
    }
}
