﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ModernHistoryMuseum
{
    
    public partial class AdminFeedbackView : Form
    {
        public string constr = @"Data Source=DESKTOP-NQ2GKGC\SQLEXPRESS;Initial Catalog=ModernHistoryMuseum_Fixed;Integrated Security=True";
        public SqlConnection conn;
        public SqlCommand comm;
        public SqlDataAdapter adap;
        public DataSet ds;
        public SqlDataReader dr;

        public AdminFeedbackView()
        {
            InitializeComponent();
        }

        private void AdminFeedbackView_Load(object sender, EventArgs e)
        {
            string select_All = "SELECT * FROM FEEDBACK";

            conn = new SqlConnection(constr);

            try
            {
                conn.Open();
                comm = new SqlCommand(select_All, conn);
                ds = new DataSet();
                adap = new SqlDataAdapter();

                adap.SelectCommand = comm;
                adap.Fill(ds, "Show");
                dgvAdminFeedback.DataSource = ds;
                dgvAdminFeedback.DataMember = "Show";

                conn.Close();
                comm.Dispose();
            }
            catch (SqlException err)
            {
                MessageBox.Show(err.Message);
            }
        }
    }
}
