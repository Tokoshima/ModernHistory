﻿namespace ModernHistoryMuseum
{
    partial class AP_INSERT
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.txtExhibitID = new System.Windows.Forms.TextBox();
            this.lblExhibit = new System.Windows.Forms.Label();
            this.txtPropID = new System.Windows.Forms.TextBox();
            this.lblProp = new System.Windows.Forms.Label();
            this.btnInsert = new System.Windows.Forms.Button();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(678, 388);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 53;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            // 
            // txtExhibitID
            // 
            this.txtExhibitID.Location = new System.Drawing.Point(183, 147);
            this.txtExhibitID.Name = "txtExhibitID";
            this.txtExhibitID.Size = new System.Drawing.Size(145, 22);
            this.txtExhibitID.TabIndex = 52;
            // 
            // lblExhibit
            // 
            this.lblExhibit.AutoSize = true;
            this.lblExhibit.Location = new System.Drawing.Point(47, 152);
            this.lblExhibit.Name = "lblExhibit";
            this.lblExhibit.Size = new System.Drawing.Size(70, 17);
            this.lblExhibit.TabIndex = 51;
            this.lblExhibit.Text = "Exhibit ID:";
            // 
            // txtPropID
            // 
            this.txtPropID.Location = new System.Drawing.Point(183, 40);
            this.txtPropID.Name = "txtPropID";
            this.txtPropID.Size = new System.Drawing.Size(145, 22);
            this.txtPropID.TabIndex = 50;
            // 
            // lblProp
            // 
            this.lblProp.AutoSize = true;
            this.lblProp.Location = new System.Drawing.Point(47, 46);
            this.lblProp.Name = "lblProp";
            this.lblProp.Size = new System.Drawing.Size(59, 17);
            this.lblProp.TabIndex = 49;
            this.lblProp.Text = "Prop ID:";
            // 
            // btnInsert
            // 
            this.btnInsert.Location = new System.Drawing.Point(183, 265);
            this.btnInsert.Name = "btnInsert";
            this.btnInsert.Size = new System.Drawing.Size(145, 32);
            this.btnInsert.TabIndex = 48;
            this.btnInsert.Text = "INSERT";
            this.btnInsert.UseVisualStyleBackColor = true;
            this.btnInsert.Click += new System.EventHandler(this.btnInsert_Click);
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(183, 90);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(145, 22);
            this.txtDescription.TabIndex = 47;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(47, 96);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 17);
            this.label1.TabIndex = 46;
            this.label1.Text = "Description:";
            // 
            // AP_INSERT
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.txtExhibitID);
            this.Controls.Add(this.lblExhibit);
            this.Controls.Add(this.txtPropID);
            this.Controls.Add(this.lblProp);
            this.Controls.Add(this.btnInsert);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.label1);
            this.Name = "AP_INSERT";
            this.Text = "AP_INSERT";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox txtExhibitID;
        private System.Windows.Forms.Label lblExhibit;
        private System.Windows.Forms.TextBox txtPropID;
        private System.Windows.Forms.Label lblProp;
        private System.Windows.Forms.Button btnInsert;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label label1;
    }
}