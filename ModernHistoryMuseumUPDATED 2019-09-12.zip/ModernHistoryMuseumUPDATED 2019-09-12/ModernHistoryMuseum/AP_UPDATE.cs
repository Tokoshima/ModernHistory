﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ModernHistoryMuseum
{
    public partial class AP_UPDATE : Form
    {
        public AP_UPDATE()
        {
            InitializeComponent();
        }
        public string conString = @"Data Source=DESKTOP-NQ2GKGC\SQLEXPRESS;Initial Catalog=ModernHistoryMuseum_Fixed;Integrated Security=True";

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string sProp = txtPropID.Text;
            string sDescription = txtDescription.Text;
            string sExhibit = txtExhibitID.Text;
            

            SqlConnection con = new SqlConnection(conString);

            if ((sExhibit == "") || (sDescription == "") || (sProp== ""))
            {
                MessageBox.Show("Please fill in the required fields");
            }

            string sUpdate = "UPDATE PROP SET Prop_ID = @PropID, Exhibit_Description = @Description, Exhibit_ID = @Exhibit";

            using (SqlCommand cmd = new SqlCommand(sUpdate, con))
            {
                cmd.Parameters.AddWithValue("@Employee", sProp);               
                cmd.Parameters.AddWithValue("@Description", sDescription);
                cmd.Parameters.AddWithValue("@ExhibitID", sExhibit);



                con.Open();
                int result = cmd.ExecuteNonQuery();

                if (result < 0)
                {
                    MessageBox.Show("Error updating table");
                }
                else
                {
                    MessageBox.Show("Updated successfully!");
                }
            }
        }
    }
}
