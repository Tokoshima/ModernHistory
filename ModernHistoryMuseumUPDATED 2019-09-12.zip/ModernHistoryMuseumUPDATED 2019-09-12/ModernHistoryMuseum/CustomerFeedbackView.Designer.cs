﻿namespace ModernHistoryMuseum
{
    partial class CustomerFeedbackView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.button1 = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.rdbOne = new System.Windows.Forms.RadioButton();
            this.rdbThree = new System.Windows.Forms.RadioButton();
            this.rdbFour = new System.Windows.Forms.RadioButton();
            this.rdbTwo = new System.Windows.Forms.RadioButton();
            this.rdbFive = new System.Windows.Forms.RadioButton();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.rtbCriteria = new System.Windows.Forms.RichTextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.btnHelp = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // button1
            // 
            this.button1.Location = new System.Drawing.Point(85, 471);
            this.button1.Margin = new System.Windows.Forms.Padding(4);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(137, 28);
            this.button1.TabIndex = 0;
            this.button1.Text = "Exit";
            this.button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(81, 57);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(143, 17);
            this.label1.TabIndex = 1;
            this.label1.Text = "Rate your experience";
            // 
            // rdbOne
            // 
            this.rdbOne.AutoSize = true;
            this.rdbOne.Location = new System.Drawing.Point(31, 119);
            this.rdbOne.Margin = new System.Windows.Forms.Padding(4);
            this.rdbOne.Name = "rdbOne";
            this.rdbOne.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.rdbOne.Size = new System.Drawing.Size(17, 16);
            this.rdbOne.TabIndex = 2;
            this.rdbOne.TabStop = true;
            this.rdbOne.UseVisualStyleBackColor = true;
            // 
            // rdbThree
            // 
            this.rdbThree.AutoSize = true;
            this.rdbThree.Location = new System.Drawing.Point(144, 119);
            this.rdbThree.Margin = new System.Windows.Forms.Padding(4);
            this.rdbThree.Name = "rdbThree";
            this.rdbThree.Size = new System.Drawing.Size(17, 16);
            this.rdbThree.TabIndex = 3;
            this.rdbThree.TabStop = true;
            this.rdbThree.UseVisualStyleBackColor = true;
            // 
            // rdbFour
            // 
            this.rdbFour.AutoSize = true;
            this.rdbFour.Location = new System.Drawing.Point(204, 119);
            this.rdbFour.Margin = new System.Windows.Forms.Padding(4);
            this.rdbFour.Name = "rdbFour";
            this.rdbFour.Size = new System.Drawing.Size(17, 16);
            this.rdbFour.TabIndex = 4;
            this.rdbFour.TabStop = true;
            this.rdbFour.UseVisualStyleBackColor = true;
            // 
            // rdbTwo
            // 
            this.rdbTwo.AutoSize = true;
            this.rdbTwo.Location = new System.Drawing.Point(85, 119);
            this.rdbTwo.Margin = new System.Windows.Forms.Padding(4);
            this.rdbTwo.Name = "rdbTwo";
            this.rdbTwo.Size = new System.Drawing.Size(17, 16);
            this.rdbTwo.TabIndex = 5;
            this.rdbTwo.TabStop = true;
            this.rdbTwo.UseVisualStyleBackColor = true;
            // 
            // rdbFive
            // 
            this.rdbFive.AutoSize = true;
            this.rdbFive.Location = new System.Drawing.Point(265, 119);
            this.rdbFive.Margin = new System.Windows.Forms.Padding(4);
            this.rdbFive.Name = "rdbFive";
            this.rdbFive.Size = new System.Drawing.Size(17, 16);
            this.rdbFive.TabIndex = 6;
            this.rdbFive.TabStop = true;
            this.rdbFive.UseVisualStyleBackColor = true;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(32, 100);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(16, 17);
            this.label2.TabIndex = 7;
            this.label2.Text = "1";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(145, 100);
            this.label3.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(16, 17);
            this.label3.TabIndex = 8;
            this.label3.Text = "3";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(205, 100);
            this.label4.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(16, 17);
            this.label4.TabIndex = 9;
            this.label4.Text = "4";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(267, 100);
            this.label5.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(16, 17);
            this.label5.TabIndex = 10;
            this.label5.Text = "5";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(87, 100);
            this.label6.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(16, 17);
            this.label6.TabIndex = 11;
            this.label6.Text = "2";
            // 
            // rtbCriteria
            // 
            this.rtbCriteria.Location = new System.Drawing.Point(16, 262);
            this.rtbCriteria.Margin = new System.Windows.Forms.Padding(4);
            this.rtbCriteria.Name = "rtbCriteria";
            this.rtbCriteria.Size = new System.Drawing.Size(300, 169);
            this.rtbCriteria.TabIndex = 12;
            this.rtbCriteria.Text = "";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(7, 209);
            this.label7.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(333, 34);
            this.label7.TabIndex = 13;
            this.label7.Text = "What did you or did not like about your experience, \r\nplease tell us more!";
            // 
            // btnHelp
            // 
            this.btnHelp.Location = new System.Drawing.Point(270, 12);
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Size = new System.Drawing.Size(75, 33);
            this.btnHelp.TabIndex = 15;
            this.btnHelp.Text = "Help";
            this.btnHelp.UseVisualStyleBackColor = true;
            // 
            // CustomerFeedbackView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(349, 514);
            this.Controls.Add(this.btnHelp);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.rtbCriteria);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.rdbFive);
            this.Controls.Add(this.rdbTwo);
            this.Controls.Add(this.rdbFour);
            this.Controls.Add(this.rdbThree);
            this.Controls.Add(this.rdbOne);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button1);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "CustomerFeedbackView";
            this.Text = "CustomerFeedbackView";
            this.Load += new System.EventHandler(this.CustomerFeedbackView_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RadioButton rdbOne;
        private System.Windows.Forms.RadioButton rdbThree;
        private System.Windows.Forms.RadioButton rdbFour;
        private System.Windows.Forms.RadioButton rdbTwo;
        private System.Windows.Forms.RadioButton rdbFive;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.RichTextBox rtbCriteria;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button btnHelp;
    }
}