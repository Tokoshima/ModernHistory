﻿namespace ModernHistoryMuseum
{
    partial class CustomerPropsView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lsbDisplayProps = new System.Windows.Forms.ListBox();
            this.rtbPropDescription = new System.Windows.Forms.RichTextBox();
            this.btnBack = new System.Windows.Forms.Button();
            this.btnHelp = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // lsbDisplayProps
            // 
            this.lsbDisplayProps.FormattingEnabled = true;
            this.lsbDisplayProps.ItemHeight = 16;
            this.lsbDisplayProps.Location = new System.Drawing.Point(16, 15);
            this.lsbDisplayProps.Margin = new System.Windows.Forms.Padding(4);
            this.lsbDisplayProps.Name = "lsbDisplayProps";
            this.lsbDisplayProps.Size = new System.Drawing.Size(209, 260);
            this.lsbDisplayProps.TabIndex = 0;
            // 
            // rtbPropDescription
            // 
            this.rtbPropDescription.Location = new System.Drawing.Point(233, 13);
            this.rtbPropDescription.Margin = new System.Windows.Forms.Padding(4);
            this.rtbPropDescription.Name = "rtbPropDescription";
            this.rtbPropDescription.Size = new System.Drawing.Size(449, 435);
            this.rtbPropDescription.TabIndex = 1;
            this.rtbPropDescription.Text = "";
            // 
            // btnBack
            // 
            this.btnBack.Location = new System.Drawing.Point(625, 498);
            this.btnBack.Margin = new System.Windows.Forms.Padding(4);
            this.btnBack.Name = "btnBack";
            this.btnBack.Size = new System.Drawing.Size(176, 41);
            this.btnBack.TabIndex = 2;
            this.btnBack.Text = "Back to Exhibit";
            this.btnBack.UseVisualStyleBackColor = true;
            // 
            // btnHelp
            // 
            this.btnHelp.Location = new System.Drawing.Point(716, 15);
            this.btnHelp.Name = "btnHelp";
            this.btnHelp.Size = new System.Drawing.Size(75, 33);
            this.btnHelp.TabIndex = 16;
            this.btnHelp.Text = "Help";
            this.btnHelp.UseVisualStyleBackColor = true;
            // 
            // CustomerPropsView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(803, 554);
            this.Controls.Add(this.btnHelp);
            this.Controls.Add(this.btnBack);
            this.Controls.Add(this.rtbPropDescription);
            this.Controls.Add(this.lsbDisplayProps);
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "CustomerPropsView";
            this.Text = "CustomerPropsView";
            this.Load += new System.EventHandler(this.CustomerPropsView_Load);
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.ListBox lsbDisplayProps;
        private System.Windows.Forms.RichTextBox rtbPropDescription;
        private System.Windows.Forms.Button btnBack;
        private System.Windows.Forms.Button btnHelp;
    }
}