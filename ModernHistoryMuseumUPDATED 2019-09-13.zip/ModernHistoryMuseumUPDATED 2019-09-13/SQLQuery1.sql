use ModernHistoryMuseum_Fixed ;

SELECT
	e.Exhibit_ID,
	p.Prop_ID,
	p.Prop_Description
FROM
	EXHIBIT e
	INNER JOIN PROP p
		ON e.Exhibit_ID = p.Exhibit_ID;
