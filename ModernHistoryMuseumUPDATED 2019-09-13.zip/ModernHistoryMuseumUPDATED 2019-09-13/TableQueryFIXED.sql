use ModernHistoryMuseum;

SELECT * FROM CUSTOMER;