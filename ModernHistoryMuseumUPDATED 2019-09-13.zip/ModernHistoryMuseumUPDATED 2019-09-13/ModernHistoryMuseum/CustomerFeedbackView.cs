﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ModernHistoryMuseum
{
    public partial class CustomerFeedbackView : Form
    {
        public CustomerFeedbackView()
        {
            InitializeComponent();
        }

        public string constr = @"Data Source=DESKTOP-NQ2GKGC\SQLEXPRESS;Initial Catalog=ModernHistoryMuseum_Fixed;Integrated Security=True";
        public SqlConnection conn;
        public SqlCommand comm;
        public SqlDataAdapter adap;
        public DataSet ds;
        public SqlDataReader dr;

        private void CustomerFeedbackView_Load(object sender, EventArgs e)
        {

        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            string sText = txtCriteria.Text;
            string sDate = txtDate.Text;
            string sRate= "";

            string sInsertF = "INSERT INTO FEEDBACK (Feedback_Date, Feedback_Rating) VALUES(@Date, @Rating)";
            string sInsertC = "INSERT INTO CRITERIA (Criteria_Description) VALUES (@Description)";

            using (conn = new SqlConnection(constr))
            {
                conn.Open();
                using (comm = new SqlCommand(sInsertF, conn))
                {
                    if (rdbOne.Checked)
                    {
                        sRate = "1";
                    }
                    if (rdbTwo.Checked)
                    {
                        sRate = "2";
                    }
                    if (rdbThree.Checked)
                    {
                        sRate = "3";
                    }
                    if (rdbFour.Checked)
                    {
                        sRate = "4";
                    }
                    if (rdbFive.Checked)
                    {
                        sRate = "5";
                    }

                    comm.Parameters.AddWithValue("@Date", sDate);
                    comm.Parameters.AddWithValue("@Rating", sRate);
                    int result1 = comm.ExecuteNonQuery();
                    using (comm = new SqlCommand(sInsertC, conn))
                    {
                       
                        comm.Parameters.AddWithValue("@Description", sText);

                        

                        int result = comm.ExecuteNonQuery();

                        if (result < 0)
                        {
                            MessageBox.Show("Error inserting into DB");
                        }
                        else
                        {
                            MessageBox.Show("Thank you for your feedback!");
                        }
                    }
                }

            }

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
