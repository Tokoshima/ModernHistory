﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ModernHistoryMuseum
{
    public partial class AEx_UPDATE : Form
    {
        public AEx_UPDATE()
        {
            InitializeComponent();
        }
        public string conString = @"Data Source=DESKTOP-NQ2GKGC\SQLEXPRESS;Initial Catalog=ModernHistoryMuseum_Fixed;Integrated Security=True";

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string sExhibit = txtExhibitID.Text;
            string sDescription = txtDescription.Text;
            string sEmployee = txtEmployeeID.Text;

            SqlConnection con = new SqlConnection(conString);

            if ((sExhibit == "") || (sDescription == "")  || (sEmployee == ""))
            {
                MessageBox.Show("Please fill in the required fields");
            }

            string sUpdate = "UPDATE EXHIBIT SET Exhibit_ID = @ExhibitID, Exhibit_Description = @Description, Employee_ID = @Employee";

            using (SqlCommand cmd = new SqlCommand(sUpdate, con))
            {
                cmd.Parameters.AddWithValue("@ExhibitID", sExhibit);
                cmd.Parameters.AddWithValue("@Description", sDescription);
                cmd.Parameters.AddWithValue("@Employee", sEmployee);


                con.Open();
                int result = cmd.ExecuteNonQuery();

                if (result < 0)
                {
                    MessageBox.Show("Error updating table");
                }
                else
                {
                    MessageBox.Show("Updated successfully!");
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
