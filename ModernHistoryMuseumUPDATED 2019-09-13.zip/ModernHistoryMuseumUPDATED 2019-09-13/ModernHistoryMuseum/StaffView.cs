﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ModernHistoryMuseum
{
    public partial class StaffView : Form
    {
        public StaffView()
        {
            InitializeComponent();
        }

        private void StaffView_Load(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            StaffStaffView frmStaff = new StaffStaffView();
            frmStaff.Show();
            this.Hide();
        }

        private void btnExhibit_Click(object sender, EventArgs e)
        {
            StaffExhibitView frmExhibit = new StaffExhibitView();
            frmExhibit.Show();
            this.Hide();
        }

        private void btnEvent_Click(object sender, EventArgs e)
        {
            StaffEventView frmEvent = new StaffEventView();
            frmEvent.Show();
            this.Hide();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            StaffCustomerView frmCustomer = new StaffCustomerView();
            frmCustomer.Show();
            this.Hide();
        }

        private void btnProp_Click(object sender, EventArgs e)
        {
            StaffPropsView frmProp = new StaffPropsView();
            frmProp.Show();
            this.Hide();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            Login frmLog = new Login();
            frmLog.Show();
            this.Hide();
        }
    }
}
