﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ModernHistoryMuseum
{
    public partial class AC_UPDATE : Form
    {
        public AC_UPDATE()
        {
            InitializeComponent();
        }

        bool isValidEmail(string sEmail)
        {
            try
            {
                var addr = new System.Net.Mail.MailAddress(sEmail);
                return addr.Address == sEmail;
            }
            catch
            {
                return false;
            }
        }

        public string conString = @"Data Source=DESKTOP-NQ2GKGC\SQLEXPRESS;Initial Catalog=ModernHistoryMuseum_Fixed;Integrated Security=True";


        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string sCustomerID = txtCustomerID.Text;
            string sFName = txtFName.Text;
            string sLName = txtLName.Text;
            string sEmail = txtEmail.Text;
            string sCell = txtCell.Text;
            string sUser = txtUser.Text;
            string sPass = txtPass.Text;

            SqlConnection con = new SqlConnection(conString);

            if (sCell.Length != 10)
            {
                MessageBox.Show("Please enter a valid number");
            }
            if (isValidEmail(sEmail) == false)
            {
                MessageBox.Show("Please enter a valid e-mail address.");
            }


            if ((sFName == "") || (sLName == "") || (sEmail == "") || (sCell == "") || (sUser == "") || (sCell == ""))
            {
                MessageBox.Show("Please fill in the required fields");
            }

            string sUpdate = "UPDATE CUSTOMER SET Customer_LName = @Customer_LName, Customer_FName = @Customer_FName, Customer_Email = @Customer_Email, Customer_Cell = @Customer_Cell, Customer_UserName = @Customer_UserName, Customer_Password = @Customer_Password";

            using (SqlCommand cmd = new SqlCommand(sUpdate, con))
            {
                cmd.Parameters.AddWithValue("@Customer_LName", sLName);
                cmd.Parameters.AddWithValue("@Customer_FName", sFName);
                cmd.Parameters.AddWithValue("@Customer_Email", sEmail);
                cmd.Parameters.AddWithValue("@Customer_Cell", sCell);
                cmd.Parameters.AddWithValue("@Customer_UserName", sUser);
                cmd.Parameters.AddWithValue("@Customer_Password", sPass);

                con.Open();
                int result = cmd.ExecuteNonQuery();

                if (result < 0)
                {
                    MessageBox.Show("Error updating table");
                }
                else
                {
                    MessageBox.Show("Updated successfully!");
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
