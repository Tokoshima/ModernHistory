﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ModernHistoryMuseum
{
    public partial class CustomerPropsView : Form
    {
        public CustomerPropsView()
        {
            InitializeComponent();
        }

        public string constr = @"Data Source=DESKTOP-NQ2GKGC\SQLEXPRESS;Initial Catalog=ModernHistoryMuseum_Fixed;Integrated Security=True";
        public SqlConnection conn;
        public SqlCommand comm;
        public SqlDataAdapter adap;
        public DataSet ds;
        public SqlDataReader dr;

        private void CustomerPropsView_Load(object sender, EventArgs e)
        {
            
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            CustomerExhibitView frmEx = new CustomerExhibitView();
            frmEx.Show();
            this.Hide();
        }

        private void cmbSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sSelectWW1 = @"SELECT Prop_Description FROM PROP WHERE Exhibit_ID = 1";
            string sSelectWW2 = @"SELECT Prop_Description FROM PROP WHERE Exhibit_ID = 2";
            string sSelectV = @"SELECT Prop_Description FROM PROP WHERE Exhibit_ID = 3";
            string sSelectCW = @"SELECT Prop_Description FROM PROP WHERE Exhibit_ID = 4";
            string sSelectBW = @"SELECT Prop_Description FROM PROP WHERE Exhibit_ID = 5";
            string sSelectGW = @"SELECT Prop_Description FROM PROP WHERE Exhibit_ID = 6";

            string sSELECTIJ = @"SELECT
	e.Exhibit_ID,
	p.Prop_ID,
	p.Prop_Description
FROM
	EXHIBIT e
	INNER JOIN PROP p
		ON e.Exhibit_ID = p.Exhibit_ID";



            conn = new SqlConnection(constr);
            conn.Open();

            if (cmbSelect.SelectedItem == "World War I")
            {
                comm = new SqlCommand(sSELECTIJ, conn);
                dr = comm.ExecuteReader();
                
                while (dr.Read())
                {
                    lstDisplay.Items.Add(dr.GetValue(0) + "\t" + dr.GetValue(1) + "\t" + dr.GetValue(2));
                }
            }
            else if (cmbSelect.SelectedItem == "World War II")
            {
                comm = new SqlCommand(sSelectWW2, conn);
                dr = comm.ExecuteReader();
                while (dr.Read())
                {
                    lstDisplay.Items.Add(dr.GetValue(0));
                }
            }
            else if (cmbSelect.SelectedItem == "Vietnam")
            {
                comm = new SqlCommand(sSelectV, conn);
                dr = comm.ExecuteReader();
                while (dr.Read())
                {
                    lstDisplay.Items.Add(dr.GetValue(0));
                }
            }
            else if (cmbSelect.SelectedItem == "American Civil War")
            {
                comm = new SqlCommand(sSelectCW, conn);
                dr = comm.ExecuteReader();
                while (dr.Read())
                {
                    lstDisplay.Items.Add(dr.GetValue(0));
                }
            }
            else if (cmbSelect.SelectedItem == "Boer War")
            {
                comm = new SqlCommand(sSelectBW, conn);
                dr = comm.ExecuteReader();
                while (dr.Read())
                {
                    lstDisplay.Items.Add(dr.GetValue(0));
                }
            }
            else if (cmbSelect.SelectedItem == "Gulf War")
            {
                comm = new SqlCommand(sSelectGW, conn);
                dr = comm.ExecuteReader();
                while (dr.Read())
                {
                    lstDisplay.Items.Add(dr.GetValue(0));
                }
            }
        }
    }
}
