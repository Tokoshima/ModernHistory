﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace ModernHistoryMuseum
{
    public partial class CustomerExhibitView : Form
    {
        public string constr = @"Data Source=DESKTOP-NQ2GKGC\SQLEXPRESS;Initial Catalog=ModernHistoryMuseum_Fixed;Integrated Security=True";
        public SqlConnection conn;
        public SqlCommand comm;
        public SqlDataAdapter adap;
        public DataSet ds;
        public SqlDataReader dr;

        public CustomerExhibitView()
        {
            InitializeComponent();
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
        }

        private void cmbSelect_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sSelectWW1 = @"SELECT Exhibit_Description FROM EXHIBIT WHERE Exhibit_ID = 1";
            string sSelectWW2 = @"SELECT Exhibit_Description FROM EXHIBIT WHERE Exhibit_ID = 2";
            string sSelectV = @"SELECT Exhibit_Description FROM EXHIBIT WHERE Exhibit_ID = 3";
            string sSelectCW = @"SELECT Exhibit_Description FROM EXHIBIT WHERE Exhibit_ID = 4";
            string sSelectBW = @"SELECT Exhibit_Description FROM EXHIBIT WHERE Exhibit_ID = 5";
            string sSelectGW = @"SELECT Exhibit_Description FROM EXHIBIT WHERE Exhibit_ID = 6";

            conn = new SqlConnection(constr);
            conn.Open();

            if (cmbSelect.SelectedItem == "World War I")
            {
                comm = new SqlCommand(sSelectWW1,conn);
                dr = comm.ExecuteReader();
                while(dr.Read())
                {
                    listBox1.Items.Add(dr.GetValue(0));
                }
            }
            else if(cmbSelect.SelectedItem == "World War II")
            {
                comm = new SqlCommand(sSelectWW2, conn);
                dr = comm.ExecuteReader();
                while (dr.Read())
                {
                    listBox1.Items.Add(dr.GetValue(0));
                }
            }
            else if (cmbSelect.SelectedItem == "Vietnam")
            {
                comm = new SqlCommand(sSelectV, conn);
                dr = comm.ExecuteReader();
                while (dr.Read())
                {
                    listBox1.Items.Add(dr.GetValue(0));
                }
            }
            else if (cmbSelect.SelectedItem == "American Civil War")
            {
                comm = new SqlCommand(sSelectCW, conn);
                dr = comm.ExecuteReader();
                while (dr.Read())
                {
                    listBox1.Items.Add(dr.GetValue(0));
                }
            }
            else if (cmbSelect.SelectedItem == "Boer War")
            {
                comm = new SqlCommand(sSelectBW, conn);
                dr = comm.ExecuteReader();
                while (dr.Read())
                {
                    listBox1.Items.Add(dr.GetValue(0));
                }
            }
            else if (cmbSelect.SelectedItem == "Gulf War")
            {
                comm = new SqlCommand(sSelectGW, conn);
                dr = comm.ExecuteReader();
                while (dr.Read())
                {
                    listBox1.Items.Add(dr.GetValue(0));
                }
            }
        }

        private void CustomerExhibitView_Load(object sender, EventArgs e)
        {
       
        }

        private void button1_Click(object sender, EventArgs e)
        {
            CustomerPropsView frmProp = new CustomerPropsView();
            frmProp.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            CustomerFeedbackView frmF = new CustomerFeedbackView();
            frmF.Show();
            ;
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            Login frmLog = new Login();
            frmLog.Show();
            this.Hide();
        }
    }
}
