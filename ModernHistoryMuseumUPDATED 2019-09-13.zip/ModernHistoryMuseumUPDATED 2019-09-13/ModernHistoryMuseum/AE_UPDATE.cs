﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ModernHistoryMuseum
{
    public partial class AE_UPDATE : Form
    {
        public AE_UPDATE()
        {
            InitializeComponent();
        }
        public string conString = @"Data Source=DESKTOP-NQ2GKGC\SQLEXPRESS;Initial Catalog=ModernHistoryMuseum_Fixed;Integrated Security=True";



        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string sEvent = txtEventID.Text;
            string sDescription = txtDescription.Text;
            string sDate = txtDate.Text;
            string sEmployee = txtEmployeeID.Text;

            SqlConnection con = new SqlConnection(conString);

            if ((sEvent == "") || (sDescription == "") || (sDate == "") || (sEmployee == ""))
            {
                MessageBox.Show("Please fill in the required fields");
            }

            string sUpdate = "UPDATE EVENT SET Event_ID = @EventID, Event_Description = @Description, Event_Date = @Date, Employee_ID = @Employee";

            using (SqlCommand cmd = new SqlCommand(sUpdate, con))
            {
                cmd.Parameters.AddWithValue("@EventID", sEvent);
                cmd.Parameters.AddWithValue("@Description", sDescription);
                cmd.Parameters.AddWithValue("@Date", sDate);
                cmd.Parameters.AddWithValue("@Employee", sEmployee);
               

                con.Open();
                int result = cmd.ExecuteNonQuery();

                if (result < 0)
                {
                    MessageBox.Show("Error updating table");
                }
                else
                {
                    MessageBox.Show("Updated successfully!");
                }
            }
        }

        private void AE_UPDATE_Load(object sender, EventArgs e)
        {

        }

        private void lblEvent_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void txtDescription_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmployeeID_TextChanged(object sender, EventArgs e)
        {

        }

        private void lblEmployee_Click(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
