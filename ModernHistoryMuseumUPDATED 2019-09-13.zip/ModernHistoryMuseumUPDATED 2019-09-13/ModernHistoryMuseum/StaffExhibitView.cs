﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ModernHistoryMuseum
{
    public partial class StaffExhibitView : Form
    {
        public string constr = @"Data Source=DESKTOP-NQ2GKGC\SQLEXPRESS;Initial Catalog=ModernHistoryMuseum_Fixed;Integrated Security=True";
        public SqlConnection conn;
        public SqlCommand comm;
        public SqlDataAdapter adap;
        public DataSet ds;
        public SqlDataReader dr;
        public StaffExhibitView()
        {
            InitializeComponent();
        }

        private void ExhibitStaff_Load(object sender, EventArgs e)
        {
            string select_All = "SELECT * FROM Exhibit";
            conn = new SqlConnection(constr);

            try
            {
                conn.Open();
                comm = new SqlCommand(select_All, conn);
                ds = new DataSet();
                adap = new SqlDataAdapter();

                adap.SelectCommand = comm;
                adap.Fill(ds, "Show");
                dgvStaffExhibitView.DataSource = ds;
                dgvStaffExhibitView.DataMember = "Show";

                conn.Close();
                comm.Dispose();
            }
            catch (SqlException err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void btnBack_Click(object sender, EventArgs e)
        {
            StaffView frmStaff = new StaffView();
            frmStaff.Show();
            this.Hide();
        }
    }
}
