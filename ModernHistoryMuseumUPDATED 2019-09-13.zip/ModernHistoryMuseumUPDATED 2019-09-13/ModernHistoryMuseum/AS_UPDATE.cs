﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace ModernHistoryMuseum
{
    public partial class AS_UPDATE : Form
    {
        public AS_UPDATE()
        {
            InitializeComponent();
        }

        public string conString = @"Data Source=DESKTOP-NQ2GKGC\SQLEXPRESS;Initial Catalog=ModernHistoryMuseum_Fixed;Integrated Security=True";

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            string sEmployee = txtEmployeeID.Text;
            string sFName = txtFName.Text;
            string sLName = txtLName.Text;
            string sEmail = txtEmail.Text;
            string sCell = txtCell.Text;
            string sUser = txtUser.Text;
            string sPass = txtPass.Text;

            SqlConnection con = new SqlConnection(conString);

            if ((sFName == "") || (sLName == "") || (sEmail == "") || (sCell == "") || (sUser == "") || (sCell == ""))
            {
                MessageBox.Show("Please fill in the required fields");
            }

            string sUpdate = "UPDATE EMPLOYEE SET Employee_LName = @Employee_LName, Employee_FName = @Employee_FName, Employee_Email = @Employee_Email, Employee_Cell = @Employee_Cell, Employee_UserName = @Employee_UserName, Employee_Password = @Employee_Password";

            using (SqlCommand cmd = new SqlCommand(sUpdate, con))
            {
                cmd.Parameters.AddWithValue("@Employee_LName", sLName);
                cmd.Parameters.AddWithValue("@Employee_FName", sFName);
                cmd.Parameters.AddWithValue("@Employee_Email", sEmail);
                cmd.Parameters.AddWithValue("@Employee_Cell", sCell);
                cmd.Parameters.AddWithValue("@Employee_UserName", sUser);
                cmd.Parameters.AddWithValue("@Employee_Password", sPass);

                con.Open();
                int result = cmd.ExecuteNonQuery();

                if (result < 0)
                {
                    MessageBox.Show("Error updating table");
                }
                else
                {
                    MessageBox.Show("Updated successfully!");
                }
            }
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            this.Hide();
        }
    }
}
