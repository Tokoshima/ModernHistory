﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace ModernHistoryMuseum
{
    public partial class AdminStaffView : Form
    {
        public string constr = @"Data Source=DESKTOP-NQ2GKGC\SQLEXPRESS;Initial Catalog=ModernHistoryMuseum_Fixed;Integrated Security=True";
        public SqlConnection conn;
        public SqlCommand comm;
        public SqlDataAdapter adap;
        public DataSet ds;
        public SqlDataReader dr;
        public AdminStaffView()
        {
            InitializeComponent();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void AdminStaffView_Load(object sender, EventArgs e)
        {
            string select_All = "SELECT * FROM EMPLOYEE";
            conn = new SqlConnection(constr);
            try
            {
                conn.Open();
                comm = new SqlCommand(select_All, conn);
                ds = new DataSet();
                adap = new SqlDataAdapter();

                adap.SelectCommand = comm;
                adap.Fill(ds, "Show");
                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Show";

                conn.Close();
                comm.Dispose();
            }
            catch (SqlException err)
            {
                MessageBox.Show(err.Message);
            }
        }

        private void BtnRemove_Click(object sender, EventArgs e)
        {
            
        }

        private void BtnAdd_Click(object sender, EventArgs e)
        {
            AS_INSERT frmAdd = new AS_INSERT();
            frmAdd.Show();
        }

        private void BtnSearch_Click(object sender, EventArgs e)
        {

        }

        private void BtnUpdate_Click(object sender, EventArgs e)
        {
            AS_UPDATE frmUp = new AS_UPDATE();
            frmUp.Show();
        }

        private void BtnBack_Click(object sender, EventArgs e)
        {
            AdminView adview = new AdminView();
            adview.Show();
            this.Hide();
        }

        private void TxbSearch_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnSearch_Click_1(object sender, EventArgs e)
        {
            string sSearch = txtSearch.Text;
            conn = new SqlConnection(constr);
            try
            {
                conn.Open();
                adap = new SqlDataAdapter();
                ds = new DataSet();
                string sqlSelect = "SELECT * FROM EMPLOYEE WHERE Employee_FName LIKE '%" + sSearch + "%'";
                SqlCommand cmd = new SqlCommand(sqlSelect, conn);

                adap.SelectCommand = cmd;
                adap.Fill(ds, "Customer");

                dataGridView1.DataSource = ds;
                dataGridView1.DataMember = "Customer";
                conn.Close();
            }
            catch (SqlException error)
            {
                MessageBox.Show(error.Message);
            }
        }
    }
}
