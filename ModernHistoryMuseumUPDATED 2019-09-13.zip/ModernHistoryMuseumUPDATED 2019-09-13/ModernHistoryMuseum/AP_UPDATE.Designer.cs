﻿namespace ModernHistoryMuseum
{
    partial class AP_UPDATE
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnClose = new System.Windows.Forms.Button();
            this.txtExhibitID = new System.Windows.Forms.TextBox();
            this.lblExhibit = new System.Windows.Forms.Label();
            this.txtPropID = new System.Windows.Forms.TextBox();
            this.lblProp = new System.Windows.Forms.Label();
            this.btnUpdate = new System.Windows.Forms.Button();
            this.txtDescription = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.SuspendLayout();
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(678, 388);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(75, 23);
            this.btnClose.TabIndex = 45;
            this.btnClose.Text = "Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // txtExhibitID
            // 
            this.txtExhibitID.Location = new System.Drawing.Point(183, 147);
            this.txtExhibitID.Name = "txtExhibitID";
            this.txtExhibitID.Size = new System.Drawing.Size(145, 22);
            this.txtExhibitID.TabIndex = 44;
            // 
            // lblExhibit
            // 
            this.lblExhibit.AutoSize = true;
            this.lblExhibit.Location = new System.Drawing.Point(47, 152);
            this.lblExhibit.Name = "lblExhibit";
            this.lblExhibit.Size = new System.Drawing.Size(70, 17);
            this.lblExhibit.TabIndex = 43;
            this.lblExhibit.Text = "Exhibit ID:";
            // 
            // txtPropID
            // 
            this.txtPropID.Location = new System.Drawing.Point(183, 40);
            this.txtPropID.Name = "txtPropID";
            this.txtPropID.Size = new System.Drawing.Size(145, 22);
            this.txtPropID.TabIndex = 42;
            // 
            // lblProp
            // 
            this.lblProp.AutoSize = true;
            this.lblProp.Location = new System.Drawing.Point(47, 46);
            this.lblProp.Name = "lblProp";
            this.lblProp.Size = new System.Drawing.Size(59, 17);
            this.lblProp.TabIndex = 41;
            this.lblProp.Text = "Prop ID:";
            // 
            // btnUpdate
            // 
            this.btnUpdate.Location = new System.Drawing.Point(183, 265);
            this.btnUpdate.Name = "btnUpdate";
            this.btnUpdate.Size = new System.Drawing.Size(145, 32);
            this.btnUpdate.TabIndex = 40;
            this.btnUpdate.Text = "UPDATE";
            this.btnUpdate.UseVisualStyleBackColor = true;
            this.btnUpdate.Click += new System.EventHandler(this.btnUpdate_Click);
            // 
            // txtDescription
            // 
            this.txtDescription.Location = new System.Drawing.Point(183, 90);
            this.txtDescription.Name = "txtDescription";
            this.txtDescription.Size = new System.Drawing.Size(145, 22);
            this.txtDescription.TabIndex = 39;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(47, 96);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(83, 17);
            this.label1.TabIndex = 38;
            this.label1.Text = "Description:";
            // 
            // AP_UPDATE
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.txtExhibitID);
            this.Controls.Add(this.lblExhibit);
            this.Controls.Add(this.txtPropID);
            this.Controls.Add(this.lblProp);
            this.Controls.Add(this.btnUpdate);
            this.Controls.Add(this.txtDescription);
            this.Controls.Add(this.label1);
            this.Name = "AP_UPDATE";
            this.Text = "AP_UPDATE";
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnClose;
        private System.Windows.Forms.TextBox txtExhibitID;
        private System.Windows.Forms.Label lblExhibit;
        private System.Windows.Forms.TextBox txtPropID;
        private System.Windows.Forms.Label lblProp;
        private System.Windows.Forms.Button btnUpdate;
        private System.Windows.Forms.TextBox txtDescription;
        private System.Windows.Forms.Label label1;
    }
}