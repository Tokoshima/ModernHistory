﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ModernHistoryMuseum
{
    public partial class AdminVisitView : Form
    {
        public AdminVisitView()
        {
            InitializeComponent();
        }

        private void AdminVisitView_Load(object sender, EventArgs e)
        {

        }
    }
}
