﻿namespace ModernHistoryMuseum
{
    partial class StaffView
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCriteria = new System.Windows.Forms.Button();
            this.btnCustomer = new System.Windows.Forms.Button();
            this.btnEvent = new System.Windows.Forms.Button();
            this.btnExhibit = new System.Windows.Forms.Button();
            this.btnFeedback = new System.Windows.Forms.Button();
            this.btnProp = new System.Windows.Forms.Button();
            this.button7 = new System.Windows.Forms.Button();
            this.button8 = new System.Windows.Forms.Button();
            this.button9 = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // btnCriteria
            // 
            this.btnCriteria.Location = new System.Drawing.Point(81, 83);
            this.btnCriteria.Name = "btnCriteria";
            this.btnCriteria.Size = new System.Drawing.Size(115, 57);
            this.btnCriteria.TabIndex = 0;
            this.btnCriteria.Text = "View Criteria";
            this.btnCriteria.UseVisualStyleBackColor = true;
            // 
            // btnCustomer
            // 
            this.btnCustomer.Location = new System.Drawing.Point(96, 209);
            this.btnCustomer.Name = "btnCustomer";
            this.btnCustomer.Size = new System.Drawing.Size(100, 53);
            this.btnCustomer.TabIndex = 1;
            this.btnCustomer.Text = "View Customer";
            this.btnCustomer.UseVisualStyleBackColor = true;
            // 
            // btnEvent
            // 
            this.btnEvent.Location = new System.Drawing.Point(58, 294);
            this.btnEvent.Name = "btnEvent";
            this.btnEvent.Size = new System.Drawing.Size(138, 69);
            this.btnEvent.TabIndex = 2;
            this.btnEvent.Text = "View Events";
            this.btnEvent.UseVisualStyleBackColor = true;
            // 
            // btnExhibit
            // 
            this.btnExhibit.Location = new System.Drawing.Point(267, 64);
            this.btnExhibit.Name = "btnExhibit";
            this.btnExhibit.Size = new System.Drawing.Size(148, 76);
            this.btnExhibit.TabIndex = 3;
            this.btnExhibit.Text = "View Exhibit";
            this.btnExhibit.UseVisualStyleBackColor = true;
            // 
            // btnFeedback
            // 
            this.btnFeedback.Location = new System.Drawing.Point(267, 179);
            this.btnFeedback.Name = "btnFeedback";
            this.btnFeedback.Size = new System.Drawing.Size(94, 58);
            this.btnFeedback.TabIndex = 4;
            this.btnFeedback.Text = "View Feedback";
            this.btnFeedback.UseVisualStyleBackColor = true;
            // 
            // btnProp
            // 
            this.btnProp.Location = new System.Drawing.Point(267, 273);
            this.btnProp.Name = "btnProp";
            this.btnProp.Size = new System.Drawing.Size(75, 23);
            this.btnProp.TabIndex = 5;
            this.btnProp.Text = "View Props";
            this.btnProp.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            this.button7.Location = new System.Drawing.Point(533, 294);
            this.button7.Name = "button7";
            this.button7.Size = new System.Drawing.Size(75, 23);
            this.button7.TabIndex = 6;
            this.button7.Text = "button7";
            this.button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            this.button8.Location = new System.Drawing.Point(286, 392);
            this.button8.Name = "button8";
            this.button8.Size = new System.Drawing.Size(75, 23);
            this.button8.TabIndex = 7;
            this.button8.Text = "button8";
            this.button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            this.button9.Location = new System.Drawing.Point(533, 214);
            this.button9.Name = "button9";
            this.button9.Size = new System.Drawing.Size(75, 23);
            this.button9.TabIndex = 8;
            this.button9.Text = "button9";
            this.button9.UseVisualStyleBackColor = true;
            // 
            // StaffView
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.button9);
            this.Controls.Add(this.button8);
            this.Controls.Add(this.button7);
            this.Controls.Add(this.btnProp);
            this.Controls.Add(this.btnFeedback);
            this.Controls.Add(this.btnExhibit);
            this.Controls.Add(this.btnEvent);
            this.Controls.Add(this.btnCustomer);
            this.Controls.Add(this.btnCriteria);
            this.Name = "StaffView";
            this.Text = "StaffView";
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCriteria;
        private System.Windows.Forms.Button btnCustomer;
        private System.Windows.Forms.Button btnEvent;
        private System.Windows.Forms.Button btnExhibit;
        private System.Windows.Forms.Button btnFeedback;
        private System.Windows.Forms.Button btnProp;
        private System.Windows.Forms.Button button7;
        private System.Windows.Forms.Button button8;
        private System.Windows.Forms.Button button9;
    }
}