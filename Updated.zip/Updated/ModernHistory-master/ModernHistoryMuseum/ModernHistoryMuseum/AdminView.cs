﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace ModernHistoryMuseum
{
    public partial class AdminView : Form
    {
        public AdminView()
        {
            InitializeComponent();
        }

        private void btnCriteria_Click(object sender, EventArgs e)
        {
            AdminCriteriaView frmCriteria = new AdminCriteriaView();
            frmCriteria.Show();
            this.Hide();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            AdminCustomerView frmCustomer = new AdminCustomerView();
            frmCustomer.Show();
            this.Hide();
        }

        private void btnEvent_Click(object sender, EventArgs e)
        {
            AdminEventView frmEvent = new AdminEventView();
            frmEvent.Show();
            this.Hide();
        }

        private void btnExhibit_Click(object sender, EventArgs e)
        {
            AdminExhibitView frmExhibit = new AdminExhibitView();
            frmExhibit.Show();
            this.Hide();
        }

        private void btnStaff_Click(object sender, EventArgs e)
        {
            AdminStaffView frmStaff = new AdminStaffView();
            frmStaff.Show();
            this.Hide();
        }

        private void btnFeedback_Click(object sender, EventArgs e)
        {
            AdminFeedbackView frmFeedback = new AdminFeedbackView();
            frmFeedback.Show();
            this.Hide();
        }

        private void btnProp_Click(object sender, EventArgs e)
        {
            AdminPropView frmProp = new AdminPropView();
            frmProp.Show();
            this.Hide();
        }

        private void btnVisits_Click(object sender, EventArgs e)
        {
            AdminVisitView frmVisit = new AdminVisitView();
            frmVisit.Show();
            this.Hide();
        }

        private void btnReturn_Click(object sender, EventArgs e)
        {
            Login frmLog = new Login();
            frmLog.Show();
            this.Hide();
        }
    }
}
